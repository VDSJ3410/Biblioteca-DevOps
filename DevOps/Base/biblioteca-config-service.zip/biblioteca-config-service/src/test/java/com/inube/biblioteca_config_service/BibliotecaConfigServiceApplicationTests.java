package com.inube.biblioteca_config_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaConfigServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
