package com.inube.biblioteca_registry_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaRegistryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
