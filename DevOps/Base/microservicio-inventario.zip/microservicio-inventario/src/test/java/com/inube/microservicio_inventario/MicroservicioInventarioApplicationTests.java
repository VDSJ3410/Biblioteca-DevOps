package com.inube.microservicio_inventario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioInventarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
