package com.inube.microservicio_cliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioClienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
